file created in order to use the setup.py file for a distribution package
