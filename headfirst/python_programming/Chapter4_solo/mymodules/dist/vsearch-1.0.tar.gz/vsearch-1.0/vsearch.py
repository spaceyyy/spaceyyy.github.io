#!python3
# vsearch.py - A program using vowels7.py from last chapter in a function.
#              Some files just used the bool() function which returned True of False,
#              did not create that in this dir due to time and breaking old habits
#              of being note happy/crazy

def search_for_vowels(phrase:str) -> set:
    """Return any vowels found in a supplied phrase."""
    vowels = set('aeiou')
    return vowels.intersection(set(phrase))

print(search_for_vowels('hello'))

def search_for_letters(phrase:str, letters:str='aieou') -> set:
    """Return any vowels found in a supplied phrase."""
    return set(letters).intersection(set(phrase))        # same as lines 9 and 10 combined

print(search_for_letters('howdy', {'h', 'y'}))
print(search_for_letters('howdy'))

# if you would like to see the results in the shell, print() the function
